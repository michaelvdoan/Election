//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#ifndef ELECTION_H
#define ELECTION_H
#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream> 
#include <iterator>
using namespace std;

enum class Party
{
    one, two, three, none
};

class Candidate
{

    public:
        Candidate(string name, Party p, int id);
        string get_name_() { return name_; };
        Party get_party_() { return party_; };
        int get_id_() { return id_; };
    
    private:
        string name_;
        Party party_;
        int id_;
};

#include "ElectoralMap.h"

class Election
{
    public:
        Election();
        Candidate get_cand( int id ) { return candidates_.at(id); };
        int get_size() { return candidates_.size(); };
        void print_candidates();
        void Register(string name, Party p);
        virtual void Report(ElectoralMap &EM);
    
    private:
        vector<Candidate> candidates_;
};


class RepresentativeElection : public Election
{
    public:
        void Report(ElectoralMap &EM);
};

#endif  // ELECTION_H
