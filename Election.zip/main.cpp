//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream> 
#include <iterator>
#include <time.h> 
#include "Election.h"
#include "ElectoralMap.h"
#include "TextUI.h"

using namespace std;

int main()
{
    srand(time(NULL));
    ElectoralMap &EM = ElectoralMap::getInstance();
    TextUI ui;
    string choice;
    // keep campainging with same electoral map
    while (choice != "0")
    {
        // ask for direct or representative
        choice = ui.ElectionType();

        if(choice == "0")
        {
            break;
        }
        
        EM.set_type(choice);
        Election *elec;

        if(choice == "direct")
        {
            elec = new Election();
        }

        if(choice == "representative")
        {
            elec = new RepresentativeElection();
        }
        
        // register candidates
        ui.Register(elec);
        // print out electoral map and candidates
        cout << EM << endl;
        elec->print_candidates();
        // campaign for all candidates
        ui.Campaign(EM, elec);
        cout << EM << endl;
        // find winner of (representative) election
        cout << "Winner: " << endl;
        ui.AnnounceWinner(EM, elec);
    }

    return 0;
}
