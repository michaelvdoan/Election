//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#ifndef ELECTORALMAP_H
#define ELECTORALMAP_H
#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream> 
#include <iterator>
#include "Election.h"

using namespace std;

class District
{
    public:
        District(int id);
        int get_size() { return size_; };
        int get_constituents(int partyKey) { return constituents.at(partyKey); };
        void Convert(int from, int to);
        friend ostream& operator<<(ostream& os, const District &dist);
    
    private:
        map<int, int> constituents; // partyKey : number of constituents
        int size_;
        int ID_;
};

class ElectoralMap
{
    public:
        static ElectoralMap& getInstance()
        {
            static ElectoralMap instance;
            return instance;
        }
    
        ElectoralMap(ElectoralMap const&) = delete; //copy constructor
        void operator=(ElectoralMap const&) = delete; //assignment operator
        District get_district(int id) { return map_districts_.at(id); };
        void set_type(string choice) { type_ = choice; } ;
        string get_type() { return type_; } ;
        int get_num_districts() { return num_districts_; };
        void Campaign(Candidate cand, int district_id);
        friend ostream& operator<<(ostream& os, const ElectoralMap &map);

    private:
        ElectoralMap();
        static const int num_districts_ = 4;
        map<int, District> map_districts_; //districtID : District pointer
        string type_; //"direct" or "representative"
};

#endif  // ELECTORALMAP_H
