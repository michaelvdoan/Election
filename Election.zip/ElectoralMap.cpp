//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream> 
#include <iterator>
#include <algorithm> 
#include <time.h> 
#include "Election.h"
#include "ElectoralMap.h"

District::District(int id)
{
    ID_ = id;
    size_ = (rand() % 29 + 5);

    for(int i = 1; i <= 4; i++) //i < number of parties, 4 = "none" party
    {
        int voters = (rand() % 10);
        constituents.insert(pair<int, int>(i, voters));
    }
}

void District::Convert(int from, int to)
{

    if(from == 4 && this->get_constituents(4) == 0)
    {
        cout << "Sorry, no one in none to convert!" << endl;
    }

    else
    {
        constituents.at(from) -= 1;
        constituents.at(to) += 1;
    }
}

ostream& operator<<(ostream& os, const District &dist)
{
    os << endl;
    os << "Square Miles: " << dist.size_ << endl;

    for(pair<int, int> it : dist.constituents)
    {
        if(it.first == 4)
        {
            os << "[Party none] : " << it.second << "\t";
        }

        else {
            os << "[Party " << it.first << "] : " << it.second << "\t";
        }
    }

    return os;
}

ElectoralMap::ElectoralMap()
{
    for(int i = 1; i <= num_districts_; i++)
    {
        District dist(i);
        map_districts_.insert(pair<int, District>(i, dist));
    }
}


void ElectoralMap::Campaign(Candidate cand, int district_id)
{
    //gets party that the candidate is affiliated with
    int party;
    string str_party;

    if(cand.get_party_() == Party::one)
    {
        party = 1;
        str_party = "one";
    }

    if(cand.get_party_() == Party::two)
    {
        party = 2;
        str_party = "two";
    }

    if(cand.get_party_() == Party::three)
    {
        party = 3;
        str_party = "three";
    }
    
    // gets party that is majority and not the Candidate's party
    int majority = 0;
    string str_majority;
    for(int i = 1; i <= 3; i++)
    {
        if(map_districts_.at(district_id).get_constituents(i) >= majority)
        {
            if(i != party)
            {
                majority = i;
            }
        }
    }

    if(majority == 1)
    {
        str_majority = "one";
    }

    if(majority == 2)
    {
        str_majority = "two";
    }

    if(majority == 3)
    {
        str_majority = "three";
    }
    
    // math for Percent success and Percent extra success
    float my_party = map_districts_.at(district_id).get_constituents(party);
    float other_parties = map_districts_.at(district_id).get_constituents(1);
    other_parties += map_districts_.at(district_id).get_constituents(2);
    other_parties += map_districts_.at(district_id).get_constituents(3);
    other_parties -= my_party;
    int area = map_districts_.at(district_id).get_size();
    float temp = ((my_party * 2.00) / other_parties)*((my_party * 2.00) / area)*100;
    float hundred = float(100);
    float P_succ = min(hundred , temp);
    float P_extra = P_succ * 0.1;
    
    cout << "Majority Party: " << str_majority << endl;
    cout << "Chances to convert: " << P_succ << endl;
    cout << "Chances to convert from another party: " << P_extra << endl;
    //Convert if success random is achieved
    int chance = rand() % 100 + 1;

    if(float(chance) <= P_succ && this->get_district(district_id).get_constituents(4))
    {
        map_districts_.at(district_id).Convert(4, party); // None -= 1, candidate's party += 1
        cout << "Congratulations, you have converted someone from none to " << str_party << "!" << endl;
    }

    // Convert if extra success random is achieved
    int extra_chance = rand() % 100 + 1;

    if(float(extra_chance) <= P_extra && this->get_district(district_id).get_constituents(majority))
    {
        map_districts_.at(district_id).Convert(majority, party); // majority other party -= 1, candidate's party += 1
        cout << "Congratulations, you have converted someone from " << str_majority << " to " << str_party << "!" << endl;
    }
}

ostream& operator<<(ostream& os, const ElectoralMap &EM)
{
    os << endl;
    for(pair<int, District> it : EM.map_districts_){
        os << "District " << it.first << ": " << it.second << '\n';
    }
    return os;
}
