//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <iomanip>
#include <sstream>
#include "Election.h"
#include "ElectoralMap.h"
#include "TextUI.h"

TextUI::TextUI()
{
    
}

string TextUI::ElectionType()
{
    cout << "What kind of election should we have (direct or representative, 0 to stop)? ";
    string choice;
    cin >> choice; //"direct" or "representative" or "0"
    return choice;
}


void TextUI::Register(Election *e)
{
    string choice1;
    while(choice1 != "n")
    {
        choice1 = "";
        cout << "Do you want to register a candidate for party one (y or n)? ";
        cin >> choice1;

        if(choice1 == "y")
        {
            string name;
            cout << "What is their name? ";
            cin >> name;
            e->Register(name, Party::one); //will assign ID inside e's Register to create Candidates
        }
    }

    string choice2;
    while(choice2 != "n")
    {
        choice2 = "";
        cout << "Do you want to register a candidate for party two (y or n)? ";
        cin >> choice2;

        if(choice2 == "y")
        {
            string name;
            cout << "What is their name? ";
            cin >> name;
            e->Register(name, Party::two); //will assign ID inside e's Register to create Candidates
        }
    }

    string choice3;
    while(choice3 != "n")
    {
        choice3 = "";
        cout << "Do you want to register a candidate for party three (y or n)? ";
        cin >> choice3;

        if(choice3 == "y")
        {
            string name;
            cout << "What is their name? ";
            cin >> name;
            e->Register(name, Party::three); //will assign ID inside e's Register to create Candidates
        }
    }

    cout << endl;
}

void TextUI::Campaign(ElectoralMap &EM, Election *elec)
{
    int choice;
    while(choice != 0)
    {
        cout << "Which candidate is campaigning (id) (0 to stop) ? ";
        cin >> choice;

        if(choice > elec->get_size() || choice == 0)
        {
            break;
        }

        cout << endl;
        cout << EM << endl;
        int where;

        while(where != 0)
        {
            cout << "Where is this candidate campaigning (id) (0 to stop) ? ";
            cin >> where;

            if(where > EM.get_num_districts() || where == 0)
            {
                break;
            }

            EM.Campaign(elec->get_cand(choice-1), where);
            cout << EM << endl;
        }
    }
}

void TextUI::AnnounceWinner(ElectoralMap &EM, Election *e)
{
    cout << endl;
    e->Report(EM);
    cout << endl;
}
