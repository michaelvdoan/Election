//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#ifndef TEXT_UI_H
#define TEXT_UI_H
#include "Election.h"
#include "ElectoralMap.h"

using namespace std;

class TextUI
{
    public:
        TextUI();
        string ElectionType();
        void Register(Election *e);
        void Campaign(ElectoralMap &EM, Election *elec);
        void AnnounceWinner(ElectoralMap &EM, Election *e);
};

#endif  // TEXT_UI_H
