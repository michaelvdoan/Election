//Michael Doan & Dennis Lim
//CSCI 3010
//HW 3

#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream> 
#include <iterator>
#include <time.h> 
#include <math.h>
#include "Election.h"
#include "ElectoralMap.h"

Candidate::Candidate(string name, Party p, int id)
{
    name_ = name;
    party_ = p;
    id_ = id;
}

Election::Election()
{
    
}

void Election::Register(string name, Party p)
{
    int cand_ID =  (int) candidates_.size() + 1;
    cout << "candidate ID: " << cand_ID << endl;
    Candidate temp = Candidate(name, p, cand_ID);
    candidates_.push_back(temp);
    cout << "Candidate " << this->get_cand(cand_ID-1).get_name_() << " added" << endl;
}

void Election::print_candidates()
{
    cout << endl;
    cout << "\t ----- " << endl;

    for(int i = 0; i < this->get_size(); i++) {
        Party tempParty = this->get_cand(i).get_party_();
        string party;
        if(tempParty == Party::one) { party = "one"; }
        if(tempParty == Party::two) { party = "two"; }
        if(tempParty == Party::three) { party = "three"; }
        cout << this->get_cand(i).get_id_() << ": " << this->get_cand(i).get_name_() << " [Party: " << party << "]" << endl;
    }
    cout << endl;
}

void Election::Report(ElectoralMap &EM)
{
    //Reports winner of Election by vote casts
    map<int, int> candidate_votes; //candidateKey : number of votes
    map<Party, int> same_party; //party (1, 2, or 3) : number of candidates

    for(int c = 0; c < this->get_size(); c++) //loop through every candidate
    {
        candidate_votes.insert(pair<int, int>(c, 0)); //insert each candidate with 0 votes
    }

    for(int k = 0; k < this->get_size(); k++) //insert each party with 0 candidates
    {
        if(this->get_cand(k).get_party_() == Party::one)
        {
            same_party.insert(pair<Party, int>(Party::one, 0));
        }

        if(this->get_cand(k).get_party_() == Party::two)
        {
            same_party.insert(pair<Party, int>(Party::two, 0));
        }

        if(this->get_cand(k).get_party_() == Party::three)
        {
            same_party.insert(pair<Party, int>(Party::three, 0));
        }
    }

    //find number of candidates in each party
    for(int p = 0; p < this->get_size(); p++) //increment each party w/ # of candidates
    {
        if(this->get_cand(p).get_party_() == Party::one)
        {
            same_party.find(Party::one)->second += 1;
        }

        if(this->get_cand(p).get_party_() == Party::two)
        {
            same_party.find(Party::two)->second += 1;
        }

        if(this->get_cand(p).get_party_() == Party::three)
        {
            same_party.find(Party::three)->second += 1;
        }
    }

    //get votes in each party
    int p1 = 0;
    int p2 = 0;
    int p3 = 0;
    int pNone = 0;

    for(int i = 1; i <= EM.get_num_districts(); i++) //loop through each district
    {
        p1 += EM.get_district(i).get_constituents(1);
        p2 += EM.get_district(i).get_constituents(2);
        p3 += EM.get_district(i).get_constituents(3);
        pNone += EM.get_district(i).get_constituents(4);
    }
    
    //make sure each vote goes to a candidate if their party does not have a candidate
    if(same_party.find(Party::one)->second == 0)
    {
        pNone += p1;
        p1 = 0;
    }

    if(same_party.find(Party::two)->second == 0)
    {
        pNone += p2;
        p2 = 0;
    }

    if(same_party.find(Party::three)->second == 0)
    {
        pNone += p3;
        p3 = 0;
    }
    
    //make sure Party::None votes for majority party
    if(p1 > p2 && p1 > p3)
    {
        p1 += pNone;
        pNone = 0;
    }

    else if(p2 > p1 && p2 > p3)
    {
        p2 += pNone;
        pNone = 0;
    }

    else if(p3 > p1 && p3 > p2)
    {
        p3 += pNone;
        pNone = 0;
    }

    else //p1 == p2 == p3, distribute randomly
    {
        while(pNone > 0)
        {
            int num = (rand() % 3 + 1); //random number 1, 2, or 3
            if(num == 1)
            {
                p1++;
            }

            if(num == 2)
            {
                p2++;
            }

            if(num == 3) {
                p3++;
            }

            pNone--;
        }
    }
    
    int j = 0; //candidate incrementor

    if(same_party.find(Party::one)->second == 1)
    {
        //cout << "one Person in Party 1" << endl;
        candidate_votes.find(j)->second += p1; //add the number of votes in
        p1 = 0;
        j++;
    }

    else if(same_party.find(Party::one)->second > 1)
    {
        int size_party = same_party.find(Party::one)->second;
        while(p1 > 0)
        {
            int num = (rand() % size_party); //random number between 0 and size of party
            candidate_votes.find(j + num)->second++;
            p1--;
        }

        j += size_party;
    }
    
    if(same_party.find(Party::two)->second == 1)
    {
        candidate_votes.find(j)->second += p2; //add the number of votes in
        p2 = 0;
        j++;
    }

    else if(same_party.find(Party::two)->second > 1)
    {
        int size_party = same_party.find(Party::two)->second;
        while(p2 > 0)
        {
            int num = (rand() % size_party); //random number between 0 and size of party
            candidate_votes.find(j + num)->second++;
            p2--;
        }

        j += size_party;
    }
    
    if(same_party.find(Party::three)->second == 1)
    {
        candidate_votes.find(j)->second += p3; //add the number of votes in
        p3 = 0;
        j++;
    }

    else if(same_party.find(Party::three)->second > 1)
    {
        int size_party = same_party.find(Party::three)->second;
        while(p3 > 0)
        {
            int num = (rand() % size_party); //random number between 0 and size of party
            candidate_votes.find(j + num)->second++;
            p3--;
        }

        j += size_party;
    }
    
    string winner = this->get_cand(0).get_name_();
    int votes = candidate_votes.find(0)->second;

    for(int i = 0; i < this->get_size(); i++)
    {
        cout << "Candidate "<< this->get_cand(i).get_id_() << " (" << this->get_cand(i).get_name_() << ") votes: " << candidate_votes.find(i)->second << endl;
        if(candidate_votes.find(i)->second > votes)
        {
            winner = this->get_cand(i).get_name_();
            votes = candidate_votes.find(i)->second;
        }
    }

    cout << endl;
    cout << "Congratulations, " << winner << ", you've won with " << votes << " votes in a direct election!" << endl;
    
}

void RepresentativeElection::Report(ElectoralMap &EM)
{
    //Reports winner of RepresentativeElection by district vote casts
    map<int, int> candidate_votes; //candidateKey : number of votes
    map<Party, int> same_party; //party (1, 2, or 3) : number of candidates
    
    for(int c = 0; c < this->get_size(); c++) //loop through every candidate
    {
        candidate_votes.insert(pair<int, int>(c, 0)); //insert each candidate w/ 0 votes
    }
    
    for(int k = 0; k < this->get_size(); k++) //insert each party w/ 0 candidates
    {
        if(this->get_cand(k).get_party_() == Party::one)
        {
            same_party.insert(pair<Party, int>(Party::one, 0));
        }

        if(this->get_cand(k).get_party_() == Party::two)
        {
            same_party.insert(pair<Party, int>(Party::two, 0));
        }

        if(this->get_cand(k).get_party_() == Party::three)
        {
            same_party.insert(pair<Party, int>(Party::three, 0));
        }
    }
    
    //find number of candidates in each party
    for(int p = 0; p < this->get_size(); p++) //increment each party w/ # of candidates
    {
        if(this->get_cand(p).get_party_() == Party::one)
        {
            same_party.find(Party::one)->second += 1;
        }

        if(this->get_cand(p).get_party_() == Party::two)
        {
            same_party.find(Party::two)->second += 1;
        }

        if(this->get_cand(p).get_party_() == Party::three)
        {
            same_party.find(Party::three)->second += 1;
        }
    }
    
    vector<float> num_voters_district; //total number of voters in each district
    float total_voters = 0.00; //total number of voters in every district
    vector<Party> district_party_winner; //winning party of each district

    for(int i = 1; i <= EM.get_num_districts(); i++) //loop through each district
    {
        //get votes in each party
        int p1 = 0;
        int p2 = 0;
        int p3 = 0;
        int pNone = 0;
        float district_voters = 0.00;
        p1 = EM.get_district(i).get_constituents(1);
        district_voters += EM.get_district(i).get_constituents(1);
        p2 = EM.get_district(i).get_constituents(2);
        district_voters += EM.get_district(i).get_constituents(2);
        p3 = EM.get_district(i).get_constituents(3);
        district_voters += EM.get_district(i).get_constituents(3);
        pNone = EM.get_district(i).get_constituents(4);
        district_voters += EM.get_district(i).get_constituents(4);
        total_voters += district_voters;
        num_voters_district.push_back(district_voters);

        // make sure each vote goes to a candidate if their party does not have a candidate
        if(same_party.find(Party::one)->second == 0)
        {
            pNone += p1;
            p1 = 0;
        }

        if(same_party.find(Party::two)->second == 0)
        {
            pNone += p2;
            p2 = 0;
        }

        if(same_party.find(Party::three)->second == 0)
        {
            pNone += p3;
            p3 = 0;
        }

        //make sure Party::None votes for majority party
        if(p1 > p2 && p1 > p3)
        {
            p1 += pNone;
            pNone = 0;
        }

        else if(p2 > p1 && p2 > p3)
        {
            p2 += pNone;
            pNone = 0;
        }

        else if(p3 > p1 && p3 > p2)
        {
            p3 += pNone;
            pNone = 0;
        }

        else //p1 == p2 == p3, distribute randomly
        {
            while(pNone > 0)
            {
                int num = (rand() % 3 + 1); //random number 1, 2, or 3
                if(num == 1) { p1++ ; }
                if(num == 2) { p2++ ; }
                if(num == 3) { p3++ ; }
                pNone--;
            }
        }
        
        //find winner of ith district
        if(p1 > p2 && p1 > p3)
        {
            district_party_winner.push_back(Party::one);
        }

        else if(p2 > p1 && p2 > p3)
        {
            district_party_winner.push_back(Party::two);
        }

        else if(p3 > p1 && p3 > p2)
        {
            district_party_winner.push_back(Party::three);
        }
    }

    vector<string> district_candidate_winner;
    
    for(int i = 0; i < EM.get_num_districts(); i++)
    {
        int j = 0; //incriments candidates
        // 1
        if(same_party.find(Party::one)->second == 1 && district_party_winner.at(i) == Party::one)
        {
            district_candidate_winner.push_back(this->get_cand(j).get_name_());
            j++;
        }

        else if(same_party.find(Party::one)->second > 1 && district_party_winner.at(i) == Party::one)
        {
            int size_party = same_party.find(Party::one)->second;
            int num = (rand() % size_party); // random number between 0 and size of party
            district_candidate_winner.push_back(this->get_cand(j+num).get_name_());
            j += size_party;
        }

        else if(same_party.find(Party::one)->second == 1)
        {
            j++;
        }

        else if(same_party.find(Party::one)->second > 1)
        {
            int size_party = same_party.find(Party::one)->second;
            j += size_party;
        }
        
        //2
        if(same_party.find(Party::two)->second == 1 && district_party_winner.at(i) == Party::two)
        {
            district_candidate_winner.push_back(this->get_cand(j).get_name_());
            j++;
        }

        else if(same_party.find(Party::two)->second > 1 && district_party_winner.at(i) == Party::two)
        {
            int size_party = same_party.find(Party::two)->second;
            int num = (rand() % size_party); //random number between 0 and size of party
            district_candidate_winner.push_back(this->get_cand(j+num).get_name_());
            j += size_party;
        }

        else if(same_party.find(Party::two)->second == 1)
        {
            j++;
        }

        else if(same_party.find(Party::two)->second > 1)
        {
            int size_party = same_party.find(Party::two)->second;
            j += size_party;
        }
        
        //3
        if(same_party.find(Party::three)->second == 1 && district_party_winner.at(i) == Party::three)
        {
            district_candidate_winner.push_back(this->get_cand(j).get_name_());
            j++;
        }

        else if(same_party.find(Party::three)->second > 1 && district_party_winner.at(i) == Party::three)
        {
            int size_party = same_party.find(Party::three)->second;
            int num = (rand() % size_party); //random number between 0 and size of party
            district_candidate_winner.push_back(this->get_cand(j+num).get_name_());
            j += size_party;
        }

        else if(same_party.find(Party::three)->second == 1)
        {
            j++;
        }

        else if(same_party.find(Party::three)->second > 1)
        {
            int size_party = same_party.find(Party::three)->second;
            j += size_party;
        }
    }
    
    float total_district_votes = 5 * EM.get_num_districts(); //total of all possible votes = 20
    vector<int> district_rep_votes; //number of representative votes each district gets
    
    for(int n = 0; n < EM.get_num_districts(); n++)
    {
        int rep_votes = floor(((num_voters_district.at(n) * 1.0) / (total_voters)) * total_district_votes);
        district_rep_votes.push_back(rep_votes);
    }

    //print out winning candidates of each district and number of representative votes they recieve
    map<string, int> winner_map; //map that adds up each winner's votes
    
    for(int i = 0; i < (int)district_candidate_winner.size(); i++)
    {
        cout << "Candidate " << district_candidate_winner.at(i) << " won district " << i+1 << "'s votes: " << district_rep_votes.at(i) << endl;
        if(winner_map.find(district_candidate_winner.at(i)) != winner_map.end())
        {
            winner_map.find(district_candidate_winner.at(i))->second +=  district_rep_votes.at(i);
        }

        else
        {
            winner_map.insert(pair<string, int> (district_candidate_winner.at(i), district_rep_votes.at(i))); 
        }
    }
    

    string winner_name;
    int winner_votes = 0;

    for(int i = 0; i < (int)winner_map.size(); i++)
    {
        if(winner_map.find(district_candidate_winner.at(i))->second > winner_votes)
        {
            winner_votes = winner_map.find(district_candidate_winner.at(i))->second;
            winner_name = district_candidate_winner.at(i); //official_winner.get_name_();
        }
    }

    cout << endl;
    cout << "Congratulations, " << winner_name << ", you've won with " << winner_votes << " votes in a representative election!" << endl;
}
